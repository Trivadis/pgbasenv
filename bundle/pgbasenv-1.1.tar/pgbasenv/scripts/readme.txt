
Each script in this directory will be available in the psql under special variable.


